var operador1
var operador2
var operacion
onclick=function Calculadora(){
	//variables
var display= document.getElementById('display')
var resultado = document.getElementById('resultado');
var on = document.getElementById('on');
var uno = document.getElementById("1");
var dos = document.getElementById("2");
var tres = document.getElementById('3');
var cuatro = document.getElementById('4');
var cinco = document.getElementById('5');
var seis = document.getElementById('6');
var siete = document.getElementById('7');
var ocho = document.getElementById('8');
var nueve = document.getElementById('9');
var cero = document.getElementById('0');
var punto = document.getElementById('punto');
var igual = document.getElementById('igual');
var dividido = document.getElementById('dividido');
var mas = document.getElementById('mas');
var menos = document.getElementById('menos');
var por = document.getElementById('por');
//	}
	//Eventos de click
reset()
uno.onclick = function(){resultado = resultado + "1";
document.getElementById("1").style.padding="4px"
document.getElementById('display').innerHTML=resultado;
resize()}
dos.onclick = function(){resultado = resultado + "2";
document.getElementById("2").style.padding="4px"
document.getElementById('display').innerHTML=resultado;
document.getElementById("2").style.padding="1px"}
tres.onclick = function(){resultado = resultado + "3";
document.getElementById("3").style.padding="4px"
document.getElementById('display').innerHTML=resultado;
document.getElementById("3").style.padding="1px"}
cuatro.onclick = function(){resultado = resultado + "4";
document.getElementById("4").style.padding="4px"
document.getElementById('display').innerHTML=resultado;
document.getElementById("4").style.padding="1px"}
cinco.onclick = function(){resultado = resultado + "5";
document.getElementById("5").style.padding="4px"
document.getElementById('display').innerHTML=resultado;
document.getElementById("5").style.padding="1px"}
seis.onclick = function(){resultado = resultado + "6";
document.getElementById("6").style.padding="4px"
document.getElementById('display').innerHTML=resultado;
document.getElementById("6").style.padding="1px"}
siete.onclick = function(){resultado = resultado + "7";
document.getElementById("7").style.padding="4px"
document.getElementById('display').innerHTML=resultado;
document.getElementById("7").style.padding="1px"}
ocho.onclick = function(){resultado = resultado + "8";
document.getElementById("8").style.padding="4px"
document.getElementById('display').innerHTML=resultado;
document.getElementById("8").style.padding="1px"}
nueve.onclick = function(){resultado = resultado + "9";
document.getElementById("9").style.padding="4px"
document.getElementById('display').innerHTML=resultado;
document.getElementById("9").style.padding="1px"}
cero.onclick = function(){resultado = resultado + "0";
document.getElementById("0").style.padding="4px"
document.getElementById('display').innerHTML=resultado;
document.getElementById("0").style.padding="1px"}
punto.onclick = function(){
var pos = resultado.indexOf(".");
if (pos>=0){} else {resultado = resultado+ ".";}
document.getElementById("punto").style.padding="4px"
document.getElementById('display').innerHTML=resultado;
document.getElementById("punto").style.padding="1px"}
sign.onclick = function(){resultado = resultado*-1;
document.getElementById("sign").style.padding="4px"
document.getElementById('display').innerHTML=resultado;
document.getElementById("sign").style.padding="1px"}
on.onclick = function(){reset();
document.getElementById("on").style.padding="4px"
document.getElementById('display').innerHTML="0";
document.getElementById("on").style.padding="1px"}
mas.onclick = function(){operando1 = resultado;
document.getElementById("mas").style.padding="4px"
operacion = "+";document.getElementById("mas").style.padding="1px"
limpiar();}
menos.onclick = function(){operando1 = resultado;
document.getElementById("menos").style.padding="4px"
operacion = "-";
limpiar();document.getElementById("menos").style.padding="1px"}
por.onclick = function(){
operando1 = resultado;
document.getElementById("por").style.padding="4px"
operacion = "*";
limpiar();document.getElementById("por").style.padding="1px"}
dividido.onclick = function(){
operando1 = resultado;
document.getElementById("dividido").style.padding="4px"
operacion = "/";
limpiar();document.getElementById("dividido").style.padding="1px"}
igual.onclick = function(){operando2 = resultado;
document.getElementById("igual").style.padding="4px"
resolver();document.getElementById('display').innerHTML=resultado;
document.getElementById("igual").style.padding="1px"}
function limpiar(){resultado = "";}
function reset(){resultado= "";
operando1 = 0;
operando2 = 0;
operacion = "";}
function resolver(){
var res = 0;
switch(operacion){
case "+":
res = parseFloat(operando1) + parseFloat(operando2);
break;
case "-":
res = parseFloat(operando1) - parseFloat(operando2);
break;
case "*":
res = parseFloat(operando1) * parseFloat(operando2);
break;
case "/":
res = parseFloat(operando1) / parseFloat(operando2);
break;}
limpiar();
resultado = res;}
function resize() {document.getElementById("1").style.padding="1px"}
function Push() {document.getElementById("1").style.padding="4px"}
//document.addEventListener('click',getElementById("1").style.padding="1px",alert("XXX"));
}()
